<?php

// src/Repository/FigureRepository.php

namespace App\Repository;

use App\Entity\Figure;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class FigureRepository extends ServiceEntityRepository
{

}
