<?php


// src/Controller/SecurityController.php

namespace App\Controller;

use App\Entity\User;
use App\Form\RegistrationFormType;
use App\Form\LoginFormType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;

class SecurityController extends AbstractController
{
    #[Route('/register', name: 'app_register')]
    public function register(Request $request, EntityManagerInterface $entityManager, UserPasswordHasherInterface $passwordHasher): Response
    {
        $user = new User();
        $form = $this->createForm(RegistrationFormType::class, $user);
    
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            // Utilise plainPassword au lieu de password
            $user->setPassword($passwordHasher->hashPassword($user, $form->get('plainPassword')->getData()));
            $entityManager->persist($user);
            $entityManager->flush();
    
            return $this->redirectToRoute('app_login');
        }
    
        return $this->render('security/register.html.twig', [
            'form' => $form->createView(),
        ]);
    }
    
    #[Route('/login', name: 'app_login')]
    public function login(AuthenticationUtils $authenticationUtils): Response
    {
        
        // Get the last authentication error if there is one
        $error = $authenticationUtils->getLastAuthenticationError();
    
        // Affichez les erreurs pour déboguer
        if ($error) {
            $this->addFlash('error', 'Erreur de connexion : ' . $error->getMessage());
        }
    
        // Vérifiez si une erreur spécifique est liée à des informations d'identification invalides
        if ($error && $error->getMessage() === 'Invalid credentials.') {
            $this->addFlash('error', 'Nom d\'utilisateur ou mot de passe incorrect.');
        }
    
        // Debug: Affichez les messages flash dans la console pour voir s'ils sont ajoutés
        dump($this->addFlash('error', 'Test de flash message')); // Pour voir si ça fonctionne
        dump($error); // Pour voir les détails de l'erreur
    
        // Create the login form
        $form = $this->createForm(LoginFormType::class);
    
        return $this->render('security/login.html.twig', [
            'form' => $form->createView(),
            'error' => $error,
        ]);
    }
    
    
    
    #[Route('/logout', name: 'app_logout')]
    public function logout(): void
    {
        // Ce code ne sera jamais exécuté. Symfony gère la déconnexion.
        throw new \Exception('This should never be reached!');
    }
}
