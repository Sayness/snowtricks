document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('figure-form');
    const deletedMediaIds = new Set();
    const deletedMediaInput = document.getElementById('deleted-media');
    const existingMediaContainer = document.getElementById('existing-media');
    const newMediaPreview = document.getElementById('new-media-preview');
    const newMediaUpload = document.getElementById('new-media-upload');
    const uploadZone = document.getElementById('upload-zone');

    // Gestion de la suppression des médias existants
    existingMediaContainer.addEventListener('click', function(e) {
        const deleteButton = e.target.closest('.delete');
        if (deleteButton) {
            const mediaItem = deleteButton.closest('.media-item');
            const mediaId = deleteButton.dataset.mediaId;

            mediaItem.style.opacity = '0';
            setTimeout(() => {
                mediaItem.remove();
            }, 300);

            deletedMediaIds.add(mediaId);
            deletedMediaInput.value = Array.from(deletedMediaIds).join(',');
        }
    });

    // Gestion du remplacement des médias
    existingMediaContainer.addEventListener('change', function(e) {
        if (e.target.classList.contains('media-replace')) {
            const file = e.target.files[0];
            if (file) {
                const mediaItem = e.target.closest('.media-item');
                const mediaId = mediaItem.dataset.mediaId;

                // Créer une prévisualisation
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = mediaItem.querySelector('img, video');
                    if (file.type.startsWith('image/')) {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        preview.replaceWith(img);
                    } else if (file.type.startsWith('video/')) {
                        const video = document.createElement('video');
                        video.controls = true;
                        const source = document.createElement('source');
                        source.src = e.target.result;
                        source.type = file.type;
                        video.appendChild(source);
                        preview.replaceWith(video);
                    }
                };
                reader.readAsDataURL(file);

                // Mettre à jour l'input pour la soumission
                const newInput = document.createElement('input');
                newInput.type = 'file';
                newInput.name = `media_replacements[${mediaId}]`;
                newInput.style.display = 'none';

                // Remplace l'ancien input s'il existe
                const existingInput = form.querySelector(`input[name="media_replacements[${mediaId}]"]`);
                if (existingInput) {
                    existingInput.remove();
                }
                
                form.appendChild(newInput);

                // Créer un nouveau FileList pour l'input
                const dataTransfer = new DataTransfer();
                dataTransfer.items.add(file);
                newInput.files = dataTransfer.files;
            }
        }
    });

    // Gestion du drag & drop pour les nouveaux médias
    // ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    //     uploadZone.addEventListener(eventName, preventDefaults, false);
    // });

    // function preventDefaults(e) {
    //     e.preventDefault();
    //     e.stopPropagation();
    // }

    // ['dragenter', 'dragover'].forEach(eventName => {
    //     uploadZone.addEventListener(eventName, () => {
    //         uploadZone.classList.add('drag-hover');
    //     });
    // });

    // ['dragleave', 'drop'].forEach(eventName => {
    //     uploadZone.addEventListener(eventName, () => {
    //         uploadZone.classList.remove('drag-hover');
    //     });
    // });

    // uploadZone.addEventListener('drop', handleDrop);
    // newMediaUpload.addEventListener('change', function(e) {
    //     handleFiles(this.files);
    // });

    // function handleDrop(e) {
    //     const dt = e.dataTransfer;
    //     const files = dt.files;
    //     handleFiles(files);
    // }

    // function handleFiles(files) {
    //     [...files].forEach(file => {
    //         if (file.type.startsWith('image/') || file.type.startsWith('video/')) {
    //             const reader = new FileReader();
    //             reader.onload = function(e) {
    //                 const mediaItem = document.createElement('div');
    //                 mediaItem.className = 'media-item new-media';
                    
    //                 if (file.type.startsWith('image/')) {
    //                     mediaItem.innerHTML = `
    //                         <img src="${e.target.result}" alt="New media">
    //                         <div class="media-actions">
    //                             <button type="button" class="action-button delete">
    //                                 <i class="fas fa-trash"></i>
    //                             </button>
    //                         </div>
    //                     `;
    //                 } else {
    //                     mediaItem.innerHTML = `
    //                         <video controls>
    //                             <source src="${e.target.result}" type="${file.type}">
    //                         </video>
    //                         <div class="media-actions">
    //                             <button type="button" class="action-button delete">
    //                                 <i class="fas fa-trash"></i>
    //                             </button>
    //                         </div>
    //                     `;
    //                 }
                    
    //                 newMediaPreview.appendChild(mediaItem);
    //             };
    //             reader.readAsDataURL(file);
    //         }
    //     });
    // }

    // Gestion de la suppression des nouveaux médias
    newMediaPreview.addEventListener('click', function(e) {
        if (e.target.closest('.delete')) {
            const mediaItem = e.target.closest('.media-item');
            mediaItem.style.opacity = '0';
            setTimeout(() => {
                mediaItem.remove();
            }, 300);
        }
    });
});

document.addEventListener("DOMContentLoaded", () => {
    const seeMediaBtn = document.getElementById("seeMediaBtn");
    const mediaList = document.getElementById("mediaList");

    // Vérifie si le bouton est visible
    if (window.getComputedStyle(seeMediaBtn).display !== "none") {
        seeMediaBtn.addEventListener("click", () => {
            mediaList.classList.toggle("hidden");
            seeMediaBtn.textContent = mediaList.classList.contains("hidden") ? "See Media" : "Hide Media";
        });
    }
});