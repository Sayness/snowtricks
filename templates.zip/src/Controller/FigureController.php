<?php

// src/Controller/FigureController.php
namespace App\Controller;

use App\Entity\Figure;
use App\Form\FigureType;
use App\Entity\Comment; 
use App\Repository\FigureRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Form\CommentFormType;

class FigureController extends AbstractController
{
    #[Route('/', name: 'figure_index')]
    public function index(FigureRepository $figureRepository): Response
    {
        $figures = $figureRepository->findAll();

        return $this->render('figure/index.html.twig', [
            'figures' => $figures,
        ]);
    }

    #[Route('/figure/new', name: 'figure_new')]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $figure = new Figure();

        // créa form pour set
        $form = $this->createForm(FigureType::class, $figure);
        
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($figure);
            $entityManager->flush();

            return $this->redirectToRoute('figure_index');
        }

        return $this->render('figure/new.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    #[Route('/figure/{id}', name: 'figure_show')]
    public function show(Figure $figure, Request $request, EntityManagerInterface $entityManager): Response
    {
        $comment = new Comment();
        $comment->setFigure($figure);
        $comment->setCreatedAt(new \DateTime());
    
        $form = $this->createForm(CommentFormType::class, $comment);
        $form->handleRequest($request);
    
        if ($form->isSubmitted() && $form->isValid()) {
            $comment->setAuthor('Anonymous'); 
            $entityManager->persist($comment);
            $entityManager->flush();
    
            return $this->redirectToRoute('figure_show', ['id' => $figure->getId()]);
        }
    
        return $this->render('figure/show.html.twig', [
            'figure' => $figure,
            'commentForm' => $form->createView(),
        ]);
    }

    #[Route('/figure/{id}/edit', name: 'figure_edit')]
    public function edit(Request $request, Figure $figure, FigureRepository $figureRepository): Response
    {
        $form = $this->createForm(FigureType::class, $figure);
        $form->handleRequest($request);
    
        if ($form->isSubmitted() && $form->isValid()) {
            $figureRepository->save($figure, true); 
    
            return $this->redirectToRoute('figure_show', ['id' => $figure->getId()]);
        }
    
        return $this->render('figure/edit.html.twig', [
            'figure' => $figure,
            'form' => $form->createView(),
        ]);
    }
    
}